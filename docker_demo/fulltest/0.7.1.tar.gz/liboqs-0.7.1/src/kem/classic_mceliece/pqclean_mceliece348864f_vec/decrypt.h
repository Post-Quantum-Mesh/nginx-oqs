#ifndef PQCLEAN_MCELIECE348864F_VEC_DECRYPT_H
#define PQCLEAN_MCELIECE348864F_VEC_DECRYPT_H
/*
  This file is for Nieddereiter decryption
*/

int PQCLEAN_MCELIECE348864F_VEC_decrypt(unsigned char * /*e*/, const unsigned char * /*sk*/, const unsigned char * /*c*/);

#endif

