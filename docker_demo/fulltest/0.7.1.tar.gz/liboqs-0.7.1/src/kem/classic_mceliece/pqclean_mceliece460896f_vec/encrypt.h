#ifndef PQCLEAN_MCELIECE460896F_VEC_ENCRYPT_H
#define PQCLEAN_MCELIECE460896F_VEC_ENCRYPT_H
/*
  This file is for Niederreiter encryption
*/


void PQCLEAN_MCELIECE460896F_VEC_encrypt(unsigned char * /*s*/, unsigned char * /*e*/, const unsigned char * /*pk*/);

#endif

