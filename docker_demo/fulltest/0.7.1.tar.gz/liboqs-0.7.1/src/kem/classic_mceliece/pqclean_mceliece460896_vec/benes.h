#ifndef PQCLEAN_MCELIECE460896_VEC_BENES_H
#define PQCLEAN_MCELIECE460896_VEC_BENES_H
/*
  This file is for Benes network related functions
*/

#include <stdint.h>

void PQCLEAN_MCELIECE460896_VEC_benes(uint64_t * /*r*/, const unsigned char * /*bits*/, int /*rev*/);

#endif

