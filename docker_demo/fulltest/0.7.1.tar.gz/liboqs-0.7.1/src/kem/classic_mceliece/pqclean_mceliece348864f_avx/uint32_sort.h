#ifndef PQCLEAN_MCELIECE348864F_AVX_UINT32_SORT_H
#define PQCLEAN_MCELIECE348864F_AVX_UINT32_SORT_H

#include <stddef.h>
#include <stdint.h>

void PQCLEAN_MCELIECE348864F_AVX_uint32_sort(uint32_t *x, size_t n);

#endif
