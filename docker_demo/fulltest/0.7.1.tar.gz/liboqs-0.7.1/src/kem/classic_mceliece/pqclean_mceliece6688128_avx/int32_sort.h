#ifndef PQCLEAN_MCELIECE6688128_AVX_INT32_SORT_H
#define PQCLEAN_MCELIECE6688128_AVX_INT32_SORT_H

#include <stddef.h>
#include <stdint.h>

void PQCLEAN_MCELIECE6688128_AVX_int32_sort(int32_t *x, size_t n);

#endif
